Author: Victor de Boer for CLARIN-VK 'Verrijkt Koninkrijk'

This folder contains a data dump of the VErrijkt Koninkrijk semantic layer. THe files are in SKOS serialized as RDF/XML, with additional metadat in Dublin Core (for the DANS DC-to-CMDI converter).

In these files, you find:
- The back of the book index in SKOS format, plus schema and SKOS linksto internal and external datasets
- The named entities index into the book in SKOS format, plus schema and SKOS links to internal and external datasets
- The NIOD thesaurus in SKOS format, plus the hierarchy, used for links from Back of the Book and Named Entity links.

